<?php

namespace app\forms;

class CalcForm {
	public $x;
	public $y;
	public $op;
} 